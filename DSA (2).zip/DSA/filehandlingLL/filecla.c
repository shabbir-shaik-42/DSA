#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Node {
    int data;
    struct Node* next;
};

void AddAtBeg(struct Node** head, int data);
void AddAtEnd(struct Node** head, int data);
void AddAtPos(struct Node** head, int data, int n);
void Delete(struct Node** head, int data);
void Display(struct Node* head);
struct Node* CreateNode(int data);

int main(int argc, char *argv[]) {
    struct Node* head = NULL; // Initialize a local head pointer
    char *filename;

    if (argc < 3) {
        printf("Usage: %s <filename> <operations>\n", argv[0]);
        return 1;
    }

    filename = argv[1];
    FILE *file = fopen(filename, "r");
    if (!file) {
        printf("Unable to open the file: %s\n", filename);
        return 1;
    }

    int data;
    while (fscanf(file, "%d", &data) == 1) {
        AddAtEnd(&head, data);
    }

    fclose(file);

    for (int i = 2; i < argc; i++) {
        if (strcmp(argv[i], "addatbeg") == 0) {
            int value = atoi(argv[++i]);
            AddAtBeg(&head, value);
        } else if (strcmp(argv[i], "addatend") == 0) {
            int value = atoi(argv[++i]);
            AddAtEnd(&head, value);
        } else if (strcmp(argv[i], "addatpos") == 0) {
            int value = atoi(argv[++i]);
            int position = atoi(argv[++i]);
            AddAtPos(&head, value, position);
        } else if (strcmp(argv[i], "delete") == 0) {
            int value = atoi(argv[++i]);
            Delete(&head, value);
        } else if (strcmp(argv[i], "display") == 0) {
            Display(head);
        } else {
            printf("Invalid operation: %s\n", argv[i]);
        }
    }

    Display(head);

    struct Node* temp;
    while (head) {
        temp = head;
        head = head->next;
        free(temp);
    }

    return 0;
}

void AddAtBeg(struct Node** head, int data) {
    struct Node* temp1 = CreateNode(data);
    temp1->next = *head;
    *head = temp1;
}

void AddAtEnd(struct Node** head, int data) {
    struct Node* newNode = CreateNode(data);

    if (*head == NULL) {
        *head = newNode;
    } else {
        struct Node* temp1 = *head;
        while (temp1->next != NULL) {
            temp1 = temp1->next;
        }
        temp1->next = newNode;
    }
}

void AddAtPos(struct Node** head, int data, int n) {
    if (n < 1) {
        printf("Invalid position. Position should be 1 or greater.\n");
        return;
    }

    struct Node* newNode = CreateNode(data);

    if (n == 1) {
        newNode->next = *head;
        *head = newNode;
        return;
    }

    struct Node* temp = *head;
    int currentPos = 1;

    while (currentPos < n - 1 && temp != NULL) {
        temp = temp->next;
        currentPos++;
    }

    if (temp == NULL) {
        printf("Invalid position. Position exceeds the length of the list.\n");
        return;
    }

    newNode->next = temp->next;
    temp->next = newNode;
}

void Delete(struct Node** head, int data) {
    if (*head == NULL) {
        printf("List is empty\n");
        return;
    }

    struct Node* temp = *head;
    struct Node* prev = NULL;

    while (temp != NULL && temp->data != data) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == NULL) {
        printf("Element not found in the list\n");
        return;
    }

    if (prev == NULL) {
        *head = temp->next;
    } else {
        prev->next = temp->next;
    }

    free(temp);
}

void Display(struct Node* head) {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }

    printf("List is: ");
    struct Node* temp = head;
    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
    }

    printf("\n");
}

struct Node* CreateNode(int data) {
    struct Node* newNode = malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}
