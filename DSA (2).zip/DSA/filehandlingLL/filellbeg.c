

/*********************************************************************
Date----> 13/10/2023
Name----> B. APUROOP KUMAR

Aim----->reading contents(numbers) in data.txt file and add at the beginning of linkedlist
 

**********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Data {
    int num;
    struct Data *next;
};

typedef struct Data Node;

Node *first = NULL;

Node *createnode(FILE *fptr);
int addatbeg(FILE *fptr);
void disp(); 

int main() {
    FILE *fptr = fopen("data.txt", "r");
    if (fptr != NULL) {
        while (addatbeg(fptr)) {
            // Continue reading until addatbeg returns 1 (success)
        }
        disp();
        fclose(fptr);
    }
    return 0;
}

int addatbeg(FILE *fptr) {
    Node *new = createnode(fptr);
    if (new) {
        if (first == NULL)
            first = new;
        else {
            new->next = first;
            first = new;
        }
        return 1; // Success
    }
    return 0; // End of file
}

void disp() {
    Node *temp = first;
    printf("List: ");
    while (temp != NULL) {
        printf("%d  ", temp->num);
        temp = temp->next;
    }
    printf("\n");
}

Node *createnode(FILE *fptr) {
    Node *new = NULL;
    int num;
    if (fscanf(fptr, "%d", &num)==1 ) { // Check if fscanf successfully read an integer
        new = malloc(sizeof(Node));
        new->num = num;
        new->next = NULL;
    }
    return new;
}

