

/*********************************************************************
Date----> 13/10/2023
Name----> B. APUROOP KUMAR

Aim----->reading contents(numbers) from data1.txt and data2.txt files and insert the elements at any position using linked lists 


**********************************************************************************/



#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Data {
    int num;
    struct Data *next;
};

typedef struct Data Node;
Node *first = NULL;

Node *createnode(int);
void addatpos(int, int);
void disp();

int main() {
    FILE *fptr1 = fopen("data1.txt", "r");
    FILE *fptr2 = fopen("data2.txt", "r");

    if (fptr1 != NULL && fptr2 != NULL) {
        int num, pos;
        int iteration = 1;

        while (fscanf(fptr1, "%d", &num) != EOF) {
            if (iteration == 1) {
                addatpos(num, 1);
            } else {
                printf("Read number %d from data1.txt in iteration %d\n", num, iteration);
                printf("Enter the position to insert this number: ");
                scanf("%d", &pos);
                addatpos(num, pos);
            }
            disp();
            iteration++;
        }

        iteration = 1;

        while (fscanf(fptr2, "%d", &num) != EOF) {

            if (iteration == 1) {
                addatpos(num, 1);
            } else {
                printf("Read number %d from data2.txt in iteration %d\n", num, iteration);
                printf("Enter the position to insert this number: ");
                scanf("%d", &pos);
                addatpos(num, pos);
            }
            disp();
            iteration++;
        }

        fclose(fptr1);
        fclose(fptr2);
    }

    return 0;
}

void addatpos(int num, int pos) {
    Node *new = createnode(num);
    if (new) {
        if (pos == 1 || first == NULL) {
            new->next = first;
            first = new;
        } else {
            Node *temp = first;
            int i = 1;
            while (i < pos - 1 && temp != NULL) {
                temp = temp->next;
                i++;
            }
            if (temp == NULL) {
                printf("Invalid position, element not inserted.\n");
            } else {
                new->next = temp->next;
                temp->next = new;
            }
        }
    }
}

void disp() {
    Node *temp = first;
    if (temp == NULL) {
        printf("List is empty.\n");
    } else {
        printf("List: ");
        while (temp != NULL) {
            printf("%d ", temp->num);
            temp = temp->next;
        }
        printf("\n");
    }
}

Node *createnode(int num) {
    Node *new = malloc(sizeof(Node));
    if (new != NULL) {
        new->num = num;
        new->next = NULL;
    }
    return new;
}
