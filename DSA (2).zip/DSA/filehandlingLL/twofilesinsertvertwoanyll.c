

/*********************************************************************
Date----> 13/10/2023
Name----> B. APUROOP KUMAR

Aim----->reading contents(numbers) from data1.txt and data2.txt files and concatenating(merging) those contents using  linked lists through string tokenisation 


**********************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Data {
    int num;
    char file[20]; // To store the file name
    struct Data *next;
};

typedef struct Data Node;
Node *first = NULL;

Node *createnode(int, const char*);
void addatpos(int, int, const char*);
void disp();

int main() {
    FILE *fptr1 = fopen("data1.txt", "r");
    FILE *fptr2 = fopen("data2.txt", "r");

    if (fptr1 != NULL && fptr2 != NULL) {
        char str[100];
        int num, pos;
        char file[20];
        int iteration = 1;

        while (fgets(str, 100, fptr1) != NULL) {
            char *ptr = strtok(str, " \n"); // Remove '\n'
            while (ptr != NULL) {
                num = atoi(ptr);
                if (iteration == 1) {
                    addatpos(num, 1, "data1.txt");
                } else {
                    printf("Read number %d from data1.txt in iteration %d\n", num, iteration);
                    printf("Enter the position to insert this number: ");
                    scanf("%d", &pos);
                    addatpos(num, pos, "data1.txt");
                }
                disp();
                ptr = strtok(NULL, " \n"); // Remove '\n'
                iteration++;
            }
        }

        iteration = 1;

        while (fgets(str, 100, fptr2) != NULL) {
            char *ptr = strtok(str, " \n"); // Remove '\n'
            while (ptr != NULL) {
                num = atoi(ptr);
                if (iteration == 1) {
                    addatpos(num, 1, "data2.txt");
                } else {
                    printf("Read number %d from data2.txt in iteration %d\n", num, iteration);
                    printf("Enter the position to insert this number: ");
                    scanf("%d", &pos);
                    addatpos(num, pos, "data2.txt");
                }
                disp();
                ptr = strtok(NULL, " \n"); // Remove '\n'

                iteration++;
            }
        }

        fclose(fptr1);
        fclose(fptr2);
    }

    return 0;
}

void addatpos(int num, int pos, const char* file) {
    Node *new = createnode(num, file);
    if (new) {
        if (pos == 1 || first == NULL) {
            new->next = first;
            first = new;
        } else {
            Node *temp = first;
            int i = 1;
            while (i < pos - 1 && temp != NULL) {
                temp = temp->next;
                i++;
            }
            if (temp == NULL) {
                printf("Invalid position, element not inserted.\n");
            } else {
                new->next = temp->next;
                temp->next = new;
            }
        }
    }
}

void disp() {
    Node *temp = first;
    printf("List: ");
    while (temp != NULL) {
        printf("%d  ", temp->num);
        temp = temp->next;
    }
    printf("\n");
}

Node *createnode(int num, const char* file) {
    Node *new = malloc(sizeof(Node));
    if (new != NULL) {
        new->num = num;
        strncpy(new->file, file, sizeof(new->file));
        new->next = NULL;
    }
    return new;
}
