

/*********************************************************************
Date----> 14/10/2023
Name----> B. APUROOP KUMAR

Aim----->read contents(numbers) from data.txt file and add at the beginning of linkedlists using string tokenising  
 

**********************************************************************************/















#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct Data
{
    int num;
    struct Data *next;
};
typedef struct Data Node;
Node *first = NULL;
Node* createnode(int );
void addatbeg(int );
void disp();

int main()
{
    FILE *fptr=fopen("data.txt","r");
    char str[100];
    if(fptr!=NULL)
    {
    fgets(str,100,fptr);
    char *ptr=strtok(str, " ");
         while(ptr!=NULL)
        {
           addatbeg(atoi(ptr));
            ptr=strtok(NULL, " ");
        }

     }
    disp();
   fclose(fptr);
}


void addatbeg(int num)
{
    Node *new =createnode(num);
    if(new)
    {
        if(first==NULL)
            first=new;
        else
        {
            new->next=first;
            first=new;
        }
    }
}


void disp()
{
    Node* temp=first;
    printf("List:");
    while(temp!=NULL)
    {
        printf("%d  ",temp->num);
        temp=temp->next;
    }
    printf("\n");
}

Node *createnode(int num)
{
    Node *new= malloc(sizeof(Node));
    if(new!=NULL)
    {
        new->num=num;
        new->next=NULL;
    }
    return new;
}

