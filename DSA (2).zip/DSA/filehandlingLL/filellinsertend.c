
/*********************************************************************
Date----> 13/10/2023
Name----> B. APUROOP KUMAR

Aim----->reading contents(numbers) from data.txt file and inserting at the end  of linked lists 
 

**********************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Data {
    int num;
    struct Data *next;
};

typedef struct Data Node;
Node *first = NULL;
Node *last = NULL;

Node *createnode(int);
void addatend(int);
void disp();

int main() {
    FILE *fptr = fopen("data.txt", "r");
    if (fptr != NULL) {
        int num;

        while (!feof(fptr)) {
            if (fscanf(fptr, "%d", &num)) {
                addatend(num);
            }
        }
        
        fclose(fptr);
        disp();
    }

    return 0;
}

void addatend(int num) {
    Node *new = createnode(num);
    if (new) {
        if (first == NULL) {
            first = last = new;
        } else {
            last->next = new;
            last = new;
        }
    }
}

void disp() {
    Node *temp = first;
    printf("List: ");
    while (temp != NULL) {
        printf("%d  ", temp->num);
        temp = temp->next;
    }
    printf("\n");
}

Node *createnode(int num) {
    Node *new = malloc(sizeof(Node));
    if (new != NULL) {
        new->num = num;
        new->next = NULL;
    }
    return new;
}

