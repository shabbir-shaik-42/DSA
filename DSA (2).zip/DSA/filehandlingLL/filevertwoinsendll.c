
/*********************************************************************
Date----> 13/10/2023
Name----> B. APUROOP KUMAR

Aim----->reading contents(numbers) from data.txt file and inserting at end of linked lists using string tokenisation
 

**********************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Data {
    int num;
    struct Data *next;
};

typedef struct Data Node;
Node *first = NULL;
Node *last = NULL;

Node *createnode(int);
void addatend(int);
void disp();

int main() {
    FILE *fptr = fopen("data.txt", "r");
    char str[100];
    if (fptr != NULL) {
        fgets(str, 100, fptr);
        char *ptr = strtok(str, " ");
        int iteration = 1;

        while (ptr != NULL) {
            int num = atoi(ptr);
            if (iteration == 1) {
                addatend(num); // Insert the first number at the end
            } else {
                printf("Read number: %d in iteration %d\n", num, iteration);
                addatend(num);
            }
            disp();
            ptr = strtok(NULL, " ");
            iteration++;
        }
    }
    fclose(fptr);
    return 0;
}

void addatend(int num) {
    Node *new = createnode(num);
    if (new) {
        if (first == NULL) {
            first = last = new;
        } else {
            last->next = new;
            last = new;
        }
    }
}

void disp() {
    Node *temp = first;
    printf("List: ");
    while (temp != NULL) {
        printf("%d  ", temp->num);
        temp = temp->next;
    }
    printf("\n");
}

Node *createnode(int num) {
    Node *new = malloc(sizeof(Node));
    if (new != NULL) {
        new->num = num;
        new->next = NULL;
    }
    return new;
}

