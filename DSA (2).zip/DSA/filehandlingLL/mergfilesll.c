
/*********************************************************************
Date----> 13/10/2023
Name----> B. APUROOP KUMAR

Aim----->reading contents(numbers) from data1.txt and data2.txt files and concatenating(merging) those contents using  linked lists 
 

**********************************************************************************/




#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Data {
    int num;
    struct Data *next;
};

typedef struct Data Node;
Node *first = NULL;

Node *createnode(int);
void addatend(int);
void disp();

int main() {
    FILE *fptr1 = fopen("data1.txt", "r");
    FILE *fptr2 = fopen("data2.txt", "r");

    if (fptr1 != NULL && fptr2 != NULL) {
        int num;

        while (fscanf(fptr1, "%d", &num) != EOF) {
            addatend(num);
        }

        while (fscanf(fptr2, "%d", &num) != EOF) {
            addatend(num);
        }

        disp();

        fclose(fptr1);
        fclose(fptr2);
    }

    return 0;
}

void addatend(int num) {
    Node *new = createnode(num);
    if (new) {
        if (first == NULL) {
            first = new;
        } else {
            Node *temp = first;
            while (temp->next != NULL) {
                temp = temp->next;
            }
            temp->next = new;
        }
    }
}

void disp() {
    Node *temp = first;
    printf("List: ");
    while (temp != NULL) {
        printf("%d ", temp->num);
        temp = temp->next;
    }
    printf("\n");
}

Node *createnode(int num) {
    Node *new = malloc(sizeof(Node));
    if (new != NULL) {
        new->num = num;
        new->next = NULL;
    }
    return new;
}
