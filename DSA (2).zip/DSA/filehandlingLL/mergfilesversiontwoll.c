
/*********************************************************************
Date----> 13/10/2023
Name----> B. APUROOP KUMAR

Aim----->reading contents(numbers) from data1.txt and data2.txt files and concatenating(merging) those contents using  linked lists through string tokenisation 


**********************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Data {
    int num;
    struct Data *next;
};

typedef struct Data Node;
Node *first = NULL;

Node *createnode(int);
void addatend(int);
void disp();

int main() {
    FILE *fptr1 = fopen("data1.txt", "r");
    FILE *fptr2 = fopen("data2.txt", "r");

    if (fptr1 != NULL && fptr2 != NULL) {
        char str[100];
        int num;
        int shouldAdd = 1; // A flag to control adding elements

        while (fgets(str, 100, fptr1) != NULL || fgets(str, 100, fptr2) != NULL) {
            char *ptr = strtok(str, " ");
            while (ptr != NULL) {
                if (sscanf(ptr, "%d", &num) == 1) {
                    if (num != 0 || shouldAdd) {
                        addatend(num);
                        shouldAdd = 1; // Reset the flag
                    }
                }
                ptr = strtok(NULL, " ");
            }
            disp();
        }

        fclose(fptr1);
        fclose(fptr2);
    }

    return 0;
}

void addatend(int num) {
    Node *new = createnode(num);
    if (new) {
        if (first == NULL) {
            first = new;
        } else {
            Node *temp = first;
            while (temp->next != NULL) {
                temp = temp->next;
            }
            temp->next = new;
        }
    }
}

void disp() {
    Node *temp = first;
    printf("Merged List: ");
    while (temp != NULL) {
        printf("%d ", temp->num);
        temp = temp->next;
    }
    printf("\n");
}

Node *createnode(int num) {
    Node *new = malloc(sizeof(Node));
    if (new != NULL) {
        new->num = num;
        new->next = NULL;
    }
    return new;
}
