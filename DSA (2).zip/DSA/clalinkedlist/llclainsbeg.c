
/*********************************************************************
Date----> 13/10/2023
Name----> B. APUROOP KUMAR

Aim----->Using command line arguments implement insertion at beginning of  linked lists 
 

**********************************************************************************/
#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* next;
};

struct Node* head;

void Insert(int data);
void Print();

int main(int argc, char *argv[]) {
    head = NULL;

    if (argc < 2) {
        printf("Usage: %s <data1> <data2> ...\n", argv[0]);
        return 1;
    }

    int numData = argc - 1;

    for (int i = 1; i <= numData; i++) {
        int data = atoi(argv[i]);
        Insert(data);
    }

    Print();

    return 0;
}

void Insert(int data) {
    struct Node* temp1 = malloc(sizeof(struct Node));
    temp1->data = data;
    temp1->next = head;
    head = temp1;
}

void Print() {
    struct Node* temp = head;
    while (temp != NULL) {
        printf("%d  ", temp->data);
        temp = temp->next;
    }
    printf("\n");
}

