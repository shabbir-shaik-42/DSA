/*********************************************************************
Date----> 14/10/2023
Name----> B. APUROOP KUMAR

Aim----->Using command line arguments implement all operations in linked lists 
 
         note----> all operations include attatbeg,addatend,addatpos,delete,display
********************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Node {
    int data;
    struct Node* next;
};

void AddAtBeg(struct Node** pHead, int data);
void AddAtEnd(struct Node** pHead, int data);
void AddAtPos(struct Node** pHead, int data, int n);
void Delete(struct Node** pHead, int data);
void Display(struct Node* head);
struct Node* CreateNode(int data);

int main(int argc, char *argv[]) {
    struct Node* head = NULL; // Initialize a local head pointer

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "addbeg") == 0) {
            int data = atoi(argv[++i]);
            AddAtBeg(&head, data);
        } else if (strcmp(argv[i], "addend") == 0) {
            int data = atoi(argv[++i]);
            AddAtEnd(&head, data);
        } else if (strcmp(argv[i], "addpos") == 0) {
            int data = atoi(argv[++i]);
            int n = atoi(argv[++i]);
            AddAtPos(&head, data, n);
        } else if (strcmp(argv[i], "delete") == 0) {
            int data = atoi(argv[++i]);
            Delete(&head, data);
        } else if (strcmp(argv[i], "display") == 0) {
            Display(head);
        } else {
            printf("Invalid command: %s\n", argv[i]);
        }
    }

    return 0;
}

void AddAtBeg(struct Node** pHead, int data) {
    struct Node* temp1 = CreateNode(data);
    temp1->next = *pHead;
    *pHead = temp1;
}

void AddAtEnd(struct Node** pHead, int data) {
    struct Node* temp1 = CreateNode(data);
    temp1->next = NULL;

    if (*pHead == NULL) {
        *pHead = temp1;
    } else {
        struct Node* temp2 = *pHead;
        while (temp2->next != NULL) {
            temp2 = temp2->next;
        }
        temp2->next = temp1;
    }
}

void AddAtPos(struct Node** pHead, int data, int n) {
    if (n < 1) {
        printf("Invalid position. Position should be 1 or greater.\n");
        return;
    }

    struct Node* newNode = CreateNode(data);
    struct Node* temp = *pHead;
    int currentPos = 1;

    while (currentPos < n - 1 && temp != NULL) {
        temp = temp->next;
        currentPos++;
    }

    if (temp == NULL) {
        printf("Invalid position. Position exceeds the length of the list.\n");
        return;
    }

    newNode->next = temp->next;
    temp->next = newNode;
}

void Delete(struct Node** pHead, int data) {
    if (*pHead == NULL) {
        printf("List is : List is empty\n");
        return;
    }

    struct Node* temp = *pHead;
    struct Node* prev = NULL;

    while (temp != NULL && temp->data != data) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == NULL) {
        printf("List is : Element not found in the list\n");
        return;
    }

    if (prev == NULL) {
        *pHead = temp->next;
    } else {
        prev->next = temp->next;
    }

    free(temp);
}

void Display(struct Node* head) {
    if (head == NULL) {
        printf("List is : List is empty\n");
        return;
    }

    printf("List is : ");
    struct Node* temp = head;
    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("\n");
}

struct Node* CreateNode(int data) {
    struct Node* newNode = malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}

