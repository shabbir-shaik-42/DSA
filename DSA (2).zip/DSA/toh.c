#include<stdio.h>
 
long long toh(int, int, int, int);



long long toh(int N, int from, int to, int mid)
{
        if(N>0)
        {
                toh(N-1,from,mid,to);
                printf("Move disk %d from rod %d to %d\n",N,from,mid);
                toh(N-1,mid, to, from);
        }
}

int main()
{

        int num;
        printf("Enter the number: ");
        scanf("%d", &num);
        toh(num, 1,3,2);
}
