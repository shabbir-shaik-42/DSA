
/**********************************************
Nmae: B.Apuroop Kumar
Date: 16/10/2023

*****************************************/
#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* next;
};

struct Stack {
    struct Node* top;
    int size;
    int maxSize;
};

struct Stack* createStack(int maxSize);
void push(struct Stack* s, int data);
int pop(struct Stack* s);
int isEmpty(struct Stack* s);
int isFull(struct Stack* s);
void printStack(struct Stack* s);

int main() {
    int maxSize;
    printf("Enter the maximum size of the stack: ");
    scanf("%d", &maxSize);
    struct Stack* stack = createStack(maxSize);

    int choice;
    int data;

    while (1) {
        printf("\nStack Operations:\n");
        printf("1. Push\n");
        printf("2. Pop\n");
        printf("3. Print Stack\n");
        printf("4. Quit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                if (isFull(stack)) {
                    printf("Stack is full. Cannot push more elements.\n");
                } else {
                    printf("Enter element to push: ");
                    scanf("%d", &data);
                    push(stack, data);
                }
                break;
            case 2:
                if (!isEmpty(stack)) {
                    int popped = pop(stack);
                    printf("Popped: %d\n", popped);
                } else {
                    printf("Stack is empty, cannot pop.\n");
                }
                break;
            case 3:
                printf("Stack elements:\n");
                printStack(stack);
                break;
            case 4:
                free(stack);
                exit(0);
                break;
            default:
                printf("Invalid choice. Please enter a valid option.\n");
        }
    }

    return 0;
}

struct Stack* createStack(int maxSize) {
    struct Stack* s = (struct Stack*)malloc(sizeof(struct Stack));
    s->top = NULL;
    s->size = 0;
    s->maxSize = maxSize;
    return s;
}

void push(struct Stack* s, int data) {
    if (isFull(s)) {
        printf("Stack is full. Cannot push more elements.\n");
        return;
    }

    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->next = s->top;
    s->top = newNode;
    s->size++;
}

int pop(struct Stack* s) {
    if (isEmpty(s)) {
        return -1;
    }

    struct Node* temp = s->top;
    s->top = temp->next;
    int data = temp->data;
    free(temp);
    s->size--;
    return data;
}

int isEmpty(struct Stack* s) {
    return s->top == NULL;
}

int isFull(struct Stack* s) {
    return s->size >= s->maxSize;
}

void printStack(struct Stack* s) {
    if (isEmpty(s)) {
        printf("Stack is empty.\n");
        return;
    }

    printf("Top --> ");
    struct Node* temp = s->top;
    while (temp != NULL) {
        printf("%d\n", temp->data);
        temp = temp->next;
        if (temp != NULL) {
            printf(" ");
        }
    }
}
