#include <stdio.h>
#include <stdbool.h>

#define MAX 5

int queue[MAX];
int front = -1;
int rear = -1;
void enqueue(int);
int isFull();
int isempty();
int dequeue();

// Function to check if the queue is full
int isFull() {
    if(rear == MAX - 1)
        return 1;
    else
        return 0;
}

// Function to check if the queue is isempty
int isEmpty()
{
    if(front==-1)
        return 1;
    else
        return 0;
}



// Function to add an element to the queue
void enqueue(int data) {
    if (isFull()) {
        printf("Queue is full. Cannot enqueue.\n");
        return;
    }
    if(isEmpty())
    {
        front=0;
    }
    
    rear++;
    queue[rear] = data;
}
// Printing the elements present in the queue
void print()
{
    int i;
    if(isEmpty())
    {
        printf("Queue is empty\n");
        return ;
    }
    for(i=rear;i>=0;i--)
    {
        printf("%d ",queue[i]);
    }
    printf("\n");
}

// Function to remove an element from the queue
int dequeue() {
    if (isEmpty()) {
        printf("Queue is empty. Cannot dequeue.\n");
        return -1;
    }
    
    int data = queue[front];
    
    if (front == rear) {
        front = rear = -1;
    } else {
        front++;
    }
    
    return data;
}


int main()
{
    int data, num=100;
    for(int i=0;i<MAX;i++)
    {
        enqueue(num+i);
    }
    printf("Elements in Queue: ");
    print();
    while((data=dequeue())!=rear)
	{
	    printf("Dequeued: %d\n",data);
	}
    return 0;
}
