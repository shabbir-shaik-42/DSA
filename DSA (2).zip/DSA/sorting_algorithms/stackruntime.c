#include <stdio.h>
#include <stdlib.h>
#define MAX 4

void push(int);
int pop();
void print();
int isFull();
int isEmpty();

int stack_arr[MAX];
int top = -1;

int main() {
    int data;

    printf("Enter 4 elements to push onto the stack:\n");

    for (int i = 0; i < MAX; i++) {
        printf("Enter element %d: ", i + 1);
        scanf("%d", &data);
        push(data);
        printf("Stack after push:\n");
        print();
    }

    if (isFull()) {
        printf("Stack is full.\n");
        int numToPop;
        printf("How many elements do you want to pop? ");
        scanf("%d", &numToPop);

        for (int i = 0; i < numToPop; i++) {
            int popped = pop();
            if (popped != -1) {
                printf("%d is popped.\n", popped);
                printf("Stack after pop:\n");
                print();
            } else {
                printf("Stack is empty, cannot pop.\n");
                break;
            }
        }
    }

    return 0;
}

// Push operation
void push(int data) {
    if (isFull()) {
        printf("Stack is full.\n");
        return;
    }
    top++;
    stack_arr[top] = data;
}

// Pop operation
int pop() {
    int value;
    if (isEmpty()) {
        printf("Stack is empty, cannot pop.\n");
        return -1;
    }
    value = stack_arr[top];
    top--;
    return value;
}

// Print the stack
void print() {
    if (isEmpty()) {
        printf("Stack is empty.\n");
        return;
    }
    for (int i = top; i >= 0; i--) {
        if (i == top) {
            printf("Top-->%d\n", stack_arr[i]);
        } else {
            printf(" %d\n", stack_arr[i]);
        }
    }
}

// Check if the stack is full
int isFull() {
    if (top == MAX - 1)
        return 1;
    return 0;
}

// Check if the stack is empty
int isEmpty() {
    if (top == -1)
        return 1;
    return 0;
}

