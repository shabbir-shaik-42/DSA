


/*********************************************************************
Date----> 12/10/2023
Name----> B. APUROOP KUMAR
**********************************************************************************/





#include <stdio.h>

// Function declarations
void merge(int arr[], int l, int m, int r);
void mergeSort(int arr[], int l, int r);

int main() {
    int n;

    printf("Enter the number of elements: ");
    scanf("%d", &n);

    int arr[n];

    printf("Enter %d elements:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    printf("Unsorted array is:\n");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    // Function calling
    mergeSort(arr, 0, n - 1);

    printf("Sorted array is:\n");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    return 0;
}

// Function definition for merge step
void merge(int arr[], int l, int m, int r) {
    int nL = m - l + 1;
    int nR = r - m;

    int L[nL], R[nR];

    for (int i = 0; i < nL; i++)
        L[i] = arr[l + i];
    for (int j = 0; j < nR; j++)
        R[j] = arr[m + 1 + j];

    int i = 0, j = 0, k = l;

    while (i < nL && j < nR) {
        if (L[i] <= R[j]) {
            arr[k] = L[i];
            i++;
        } else {
            arr[k] = R[j];
            j++;
        }
        k++;
    }

    while (i < nL) {
        arr[k] = L[i];
        i++;
        k++;
    }

    while (j < nR) {
        arr[k] = R[j];
        j++;
        k++;
    }
}

// Function definition for merge sort
void mergeSort(int arr[], int l, int r) {
    if (l < r) {
        int m = l + (r - l) / 2;
        mergeSort(arr, l, m);
        mergeSort(arr, m + 1, r);
        merge(arr, l, m, r);
    }
}
