#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* next;
    struct Node* prev;
};

struct Node* head = NULL; // Global head pointer for a doubly circular linked list

void AddAtBeg(int data);
void AddAtEnd(int data);
void AddAtPos(int data, int n);
void Delete(int data);
void ReverseList();
void Display();

int main() {
    // Insert elements into the list
    AddAtBeg(10);
    AddAtEnd(20);
    
    // Adding at an invalid position
    AddAtPos(25, 15); // Invalid position

    // Display the original list
    printf("Original List:\n");
    Display();

    // Reverse the list
    ReverseList();

    // Display the reversed list
    printf("Reversed List:\n");
    Display();

    return 0;
}

void AddAtBeg(int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;

    if (head == NULL) {
        head = newNode;
        newNode->next = newNode;
        newNode->prev = newNode;
    } else {
        newNode->next = head;
        newNode->prev = head->prev;
        head->prev->next = newNode;
        head->prev = newNode;
        head = newNode;
    }
}

void AddAtEnd(int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;

    if (head == NULL) {
        head = newNode;
        newNode->next = newNode;
        newNode->prev = newNode;
    } else {
        newNode->next = head;
        newNode->prev = head->prev;
        head->prev->next = newNode;
        head->prev = newNode;
    }
}

void AddAtPos(int data, int n) {
    if (n <= 0) {
        printf("Invalid position. Position should be 1 or greater.\n");
        return;
    }

    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;

    if (n == 1) {
        newNode->next = head;
        newNode->prev = head->prev;
        head->prev->next = newNode;
        head->prev = newNode;
        head = newNode;
    } else {
        struct Node* temp = head;
        int currentPos = 1;

        while (currentPos < n - 1 && temp->next != head) {
            temp = temp->next;
            currentPos++;
        }

        if (currentPos != n - 1 || temp->next == head) {
            printf("Invalid position. Position exceeds the length of the list.\n");
            free(newNode);
        } else {
            newNode->next = temp->next;
            newNode->prev = temp;
            temp->next->prev = newNode;
            temp->next = newNode;
        }
    }
}

void Delete(int data) {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }

    struct Node* temp = head;

    do {
        if (temp->data == data) {
            temp->prev->next = temp->next;
            temp->next->prev = temp->prev;
            if (temp == head) {
                head = temp->next;
            }
            free(temp);
            return;
        }
        temp = temp->next;
    } while (temp != head);

    printf("Element not found in the list\n");
}

void ReverseList() {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }

    struct Node* current = head;
    struct Node* temp;

    do {
        temp = current->next;
        current->next = current->prev;
        current->prev = temp;
        current = temp;
    } while (current != head);

    head = head->next; // Update the global head to the last node
}

void Display() {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }

    struct Node* temp = head;

    do {
        printf("%d ", temp->data);
        temp = temp->next;
    } while (temp != head);

    printf("\n");
}
