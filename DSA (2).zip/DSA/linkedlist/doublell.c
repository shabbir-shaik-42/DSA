
/**********************************************
Nmae: B.Apuroop Kumar
Date: 16/10/2023

*****************************************/

#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* next;
    struct Node* prev;
};

struct Node* head = NULL; // Global head pointer for a doubly linked list

struct Node* CreateNode(int data);
void AddAtBeg(int data);
void AddAtEnd(int data);
void AddAtPos(int data, int n);
void Delete(int data);
void ReverseList();
void Display();

int main() {
    // Insert elements into the list
    AddAtBeg(10);
    AddAtEnd(20);
    AddAtPos(15, 2);

    // Display the list
    printf("Original List:\n");
    Display();

    // Reverse the list
    ReverseList();
    
    // Display the reversed list
    printf("Reversed List:\n");
    Display();

    return 0;
}

struct Node* CreateNode(int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->next = NULL;
    newNode->prev = NULL;
    return newNode;
}

void AddAtBeg(int data) {
    struct Node* newNode = CreateNode(data);
    newNode->next = head;
    
    if (head != NULL) {
        head->prev = newNode;
    }

    head = newNode;
}

void AddAtEnd(int data) {
    struct Node* newNode = CreateNode(data);

    if (head == NULL) {
        head = newNode;
        return;
    }

    struct Node* temp = head;
    while (temp->next != NULL) {
        temp = temp->next;
    }

    temp->next = newNode;
    newNode->prev = temp;
}

void AddAtPos(int data, int n) {
    if (n <= 0) {
        printf("Invalid position. Position should be 1 or greater.\n");
        return;
    }

    if (n == 1) {
        AddAtBeg(data);
        return;
    }

    struct Node* newNode = CreateNode(data);

    struct Node* temp = head;
    int currentPos = 1;

    while (currentPos < n - 1 && temp != NULL) {
        temp = temp->next;
        currentPos++;
    }

    if (temp == NULL) {
        printf("Invalid position. Position exceeds the length of the list.\n");
        free(newNode);
        return;
    }

    newNode->next = temp->next;
    if (temp->next != NULL) {
        temp->next->prev = newNode;
    }
    newNode->prev = temp;
    temp->next = newNode;
}

void Delete(int data) {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }

    struct Node* temp = head;

    while (temp != NULL) {
        if (temp->data == data) {
            if (temp->prev != NULL) {
                temp->prev->next = temp->next;
            } else {
                head = temp->next;
            }
            if (temp->next != NULL) {
                temp->next->prev = temp->prev;
            }
            free(temp);
            return;
        }
        temp = temp->next;
    }

    printf("Element not found in the list\n");
}

void ReverseList() {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }

    struct Node* current = head;
    struct Node* temp;

    while (current != NULL) {
        temp = current->prev;
        current->prev = current->next;
        current->next = temp;
        current = current->prev;
    }

    head = temp->prev;
}

void Display() {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }

    struct Node* temp = head;

    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
    }

    printf("\n");
}
