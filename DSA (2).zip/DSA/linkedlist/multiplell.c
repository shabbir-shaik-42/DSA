



/*********************************************************************
Date----> 12/10/2023
Name----> B. APUROOP KUMAR
Aim-----> Multiple linked lists
**********************************************************************************/

















#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* next;
};

void AddAtBeg(struct Node** pHead, int data);
void AddAtEnd(struct Node** pHead, int data);
void AddAtPos(struct Node** pHead, int data, int n);
void Delete(struct Node** pHead, int data);
void Display(struct Node* head);
struct Node* CreateNode(int data);

int main() {
    struct Node* list1 = NULL; // Initialize the first linked list
    struct Node* list2 = NULL; // Initialize the second linked list

    // Operations on the first linked list (list1)
    AddAtBeg(&list1, 10);
    AddAtBeg(&list1, 20);
    AddAtBeg(&list2, 1);
    AddAtPos(&list2, 2,1);
    Delete(&list1,10);
    AddAtEnd(&list1, 30);
    Delete(&list2,2);
    // Display the first linked list
    printf("List 1: ");
    Display(list1);

    // Operations on the second linked list (list2)
    AddAtBeg(&list2, 5);
    AddAtEnd(&list2, 15);
    AddAtPos(&list2, 25, 2);

    // Display the second linked list
    printf("List 2: ");
    Display(list2);

    // Clean up and free the memory for both lists
    while (list1 != NULL) {
        Delete(&list1, list1->data);
    }

    while (list2 != NULL) {
        Delete(&list2, list2->data);
    }

    return 0;
}

void AddAtBeg(struct Node** pHead, int data) {
    struct Node* temp1 = CreateNode(data);
    temp1->next = *pHead;
    *pHead = temp1;
}

void AddAtEnd(struct Node** pHead, int data) {
    struct Node* newNode = CreateNode(data);
   // temp1->next = NULL;

    if (*pHead == NULL) {
        *pHead = newNode;
    } else {
        struct Node* temp1 = *pHead;
        while (temp1->next != NULL) {
            temp1 = temp1->next;
        }
        temp1->next = newNode;
    }
}

void AddAtPos(struct Node** pHead, int data, int n) {
    if (n < 1) {
        printf("Invalid position. Position should be 1 or greater.\n");
        return;
    }

    struct Node* newNode = CreateNode(data);
    struct Node* temp = *pHead;
    int currentPos = 1;

    while (currentPos < n - 1 && temp != NULL) {
        temp = temp->next;
        currentPos++;
    }

    if (temp == NULL) {
        printf("Invalid position. Position exceeds the length of the list.\n");
        return;
    }

    newNode->next = temp->next;
    temp->next = newNode;
}

void Delete(struct Node** pHead, int data) {
    if (*pHead == NULL) {
        printf("List is : List is empty\n");
        return;
    }

    struct Node* temp = *pHead;
    struct Node* prev = NULL;

    while (temp != NULL && temp->data != data) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == NULL) {
        printf("List is : Element not found in the list\n");
        return;
    }

    if (prev == NULL) {
        *pHead = temp->next;
    } else {
        prev->next = temp->next;
    }

    free(temp);
}

void Display(struct Node* head) {
    if (head == NULL) {
        printf("List is : List is empty\n");
        return;
    }

    printf("List is : ");
    struct Node* temp = head;
    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("\n");
}

struct Node* CreateNode(int data) {
    struct Node* newNode = malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}

