/**********************************************
Nmae: B.Apuroop Kumar
Date: 16/10/2023

*****************************************/

#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* next;
};

void AddAtBeg(struct Node** head, int data);
void AddAtEnd(struct Node** head, int data);
void AddAtPos(struct Node** head, int data, int n);
void Delete(struct Node** head, int data);
void Display(struct Node* head);
struct Node* CreateNode(int data);
struct Node* ReverseList(struct Node* head);

int main() {
    struct Node* head = NULL; // Initialize a local head pointer

    // Insert elements into the list
    AddAtBeg(&head, 10);
    AddAtBeg(&head, 20);
    AddAtBeg(&head, 30);
    AddAtBeg(&head, 40);
    AddAtBeg(&head, 50);

    // Display the original list
    printf("Original List:\n");
    Display(head);

    // Reverse the list
    head = ReverseList(head);

    // Display the reversed list
    printf("Reversed List:\n");
    Display(head);

    return 0;
}

void AddAtBeg(struct Node** head, int data) {
    struct Node* temp1 = CreateNode(data);
    temp1->next = *head;
    *head = temp1;
}

void AddAtEnd(struct Node** head, int data) {
    struct Node* newNode = CreateNode(data);
    if (*head == NULL) {
        *head = newNode;
    } else {
        struct Node* temp = *head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = newNode;
    }
}

void AddAtPos(struct Node** head, int data, int n) {
    if (n <= 0) {
        printf("Invalid position. Position should be 1 or greater.\n");
        return;
    }

    struct Node* newNode = CreateNode(data);

    if (n == 1 || *head == NULL) {
        newNode->next = *head;
        *head = newNode;
    } else {
        struct Node* temp = *head;
        int currentPos = 1;

        while (currentPos < n - 1 && temp->next != NULL) {
            temp = temp->next;
            currentPos++;
        }

        newNode->next = temp->next;
        temp->next = newNode;
    }
}

void Delete(struct Node** head, int data) {
    if (*head == NULL) {
        printf("List is empty\n");
        return;
    }

    struct Node* temp = *head;
    struct Node* prev = NULL;

    while (temp != NULL && temp->data != data) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == NULL) {
        printf("Element not found in the list\n");
        return;
    }

    if (prev == NULL) {
        *head = temp->next;
    } else {
        prev->next = temp->next;
    }

    free(temp);
}

void Display(struct Node* head) {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }

    printf("List is: ");
    struct Node* temp = head;
    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("\n");
}

struct Node* CreateNode(int data) {
    struct Node* newNode = malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}

struct Node* ReverseList(struct Node* head) {
    struct Node* prev = NULL;
    struct Node* current = head;
    struct Node* next = NULL;

    while (current != NULL) {
        next = current->next;
        current->next = prev;
        prev = current;
        current = next;
    }

    return prev; // The new head is the last element (previously first)
}
