/***************************
  ****************************
  Inserting elements at the beginning in a linked list
  ***********************
  **********************************************/


#include<stdio.h>
#include<stdlib.h>
struct Node
{
    int data;
    struct Node* next;//stores the address of the next node (here node is a structure type)
};
struct Node* head;//(global)variable that will be pointer to node and that will store the first(head) node in the linked list

/************Function Declarations***********/
void Insert(int);
void Print();
/**************Main Function**************************/

int main()
{
    head=NULL;//empty list
    printf("How many numbers?\n");
    int n,i,x;
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        printf("Enter the number\n");
        scanf("%d",&x);
        Insert(x);
        Print();
    }
}

/*************Insert Function Definition***********/

void Insert(int x)
{

struct Node*  temp =  malloc(sizeof(struct Node));//malloc returns the pointer to the starting address of the memory block
temp->data =x;
temp->next =head;
head=temp;
}
/************Print Function***************************************/
void Print()
{
struct Node* temp=head;//address of the head node.why temporary variable?not to modify the head.we dont want to loose the reference of the first node hence collect the address of head in anoher temporary variable and we will modify address in this temporary variable
printf("List is:");
      while(temp!=NULL)
     {
         printf("%d  ",temp->data);
             temp=temp->next;
     }
printf("\n");
}

