#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* next;
};

struct Node* head;

void InsertAtEnd(int data);
void Print();

int main() {
    head = NULL;

    int n; // Number of elements in the linked list
    printf("Enter the number of elements in the linked list: ");
    scanf("%d", &n);

    for (int i = 1; i <= n; i++) {
        int data;
        printf("Enter data for element %d: ", i);
        scanf("%d", &data);
        InsertAtEnd(data);

        // Display the linked list after each insert
        Print();
    }
}

void InsertAtEnd(int data) {
    struct Node* new_node = malloc(sizeof(struct Node));
    new_node->data = data;
    new_node->next = NULL;

    if (head == NULL) {
        head = new_node;
        return;
    }

    struct Node* temp = head;
    while (temp->next != NULL) {
        temp = temp->next;
    }

    temp->next = new_node;
}

void Print() {
    struct Node* temp = head;
    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("\n");
}
