#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* next;
};

void AddAtBeg(struct Node** pHead, int data);
void Delete(struct Node** pHead, int data);
void Display(struct Node* head);
struct Node* CreateNode(int data);

int main() {
    int sizes[] = {10, 20, 15, 5}; // Specify the sizes of linked lists
    int numLists = sizeof(sizes) / sizeof(sizes[0]);

    struct Node* lists[numLists]; // Array of pointers to linked lists

    // Initialize and populate the linked lists
    for (int i = 0; i < numLists; i++) {
        lists[i] = NULL; // Initialize each linked list

        for (int j = 0; j < sizes[i]; j++) {
            AddAtBeg(&lists[i], i * 10 + j);
        }
    }

    // Display the linked lists
    for (int i = 0; i < numLists; i++) {
        printf("List %d: ", i);
        Display(lists[i]);
    }

    // Clean up and free the memory for each linked list
    for (int i = 0; i < numLists; i++) {
        while (lists[i] != NULL) {
            Delete(&lists[i], lists[i]->data);
        }
    }

    return 0;
}

void AddAtBeg(struct Node** pHead, int data) {
    struct Node* temp1 = CreateNode(data);
    temp1->next = *pHead;
    *pHead = temp1;
}

void Delete(struct Node** pHead, int data) {
    if (*pHead == NULL) {
        printf("List is empty\n");
        return;
    }

    struct Node* temp = *pHead;
    struct Node* prev = NULL;

    while (temp != NULL && temp->data != data) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == NULL) {
        printf("Element not found in the list\n");
        return;
    }

    if (prev == NULL) {
        *pHead = temp->next;
    } else {
        prev->next = temp->next;
    }

    free(temp);
}

void Display(struct Node* head) {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }

    struct Node* temp = head;
    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("\n");
}

struct Node* CreateNode(int data) {
    struct Node* newNode = malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}

