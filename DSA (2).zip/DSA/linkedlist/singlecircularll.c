
/**********************************************
Nmae: B.Apuroop Kumar
Date: 16/10/2023

*****************************************/

#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* next;
};

struct Node* head = NULL; // Global head pointer for a circular linked list

void AddAtBeg(int data);
void AddAtEnd(int data);
void AddAtPos(int data, int n);
void Delete(int data);
void ReverseList();
void Display();

int main() {
    // Insert elements into the list
    AddAtBeg(10);
    AddAtEnd(20);
    AddAtPos(15, 2);

    // Display the original list
    printf("Original List:\n");
    Display();

    // Reverse the list
    ReverseList();

    // Display the reversed list
    printf("Reversed List:\n");
    Display();

    // Adding at an invalid position
    AddAtPos(25, -1); // Invalid position

    return 0;
}

void AddAtBeg(int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;

    if (head == NULL) {
        newNode->next = newNode; // Point to itself in a circular list
        head = newNode; // Update the global head
    } else {
        struct Node* temp = head;
        while (temp->next != head) {
            temp = temp->next;
        }
        temp->next = newNode; // Connect the last node to the new node
        newNode->next = head; // Make the new node the new head
        head = newNode; // Update the global head
    }
}

void AddAtEnd(int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->next = head;

    if (head == NULL) {
        head = newNode; // Update the global head
        newNode->next = head; // Point to itself in a circular list
    } else {
        struct Node* temp = head;
        while (temp->next != head) {
            temp = temp->next;
        }
        temp->next = newNode; // Connect the last node to the new node
    }
}

void AddAtPos(int data, int n) {
    if (n <= 0) {
        printf("Invalid position. Position should be 1 or greater.\n");
        return;
    }

    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;

    if (n == 1) {
        newNode->next = head;
        head = newNode;
    } else {
        struct Node* temp = head;
        int currentPos = 1;

        while (currentPos < n - 1 && temp->next != head) {
            temp = temp->next;
            currentPos++;
        }

        if (temp->next != head) {
            newNode->next = temp->next;
            temp->next = newNode;
        } else {
            printf("Invalid position. Position exceeds the length of the list.\n");
            free(newNode);
        }
    }
}

void Delete(int data) {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }

    struct Node* temp = head;
    struct Node* prev = NULL;

    do {
        if (temp->data == data) {
            if (prev == NULL) {
                head = temp->next; // Update the global head
            } else {
                prev->next = temp->next;
            }
            free(temp);
            return;
        }
        prev = temp;
        temp = temp->next;
    } while (temp != head);

    printf("Element not found in the list\n");
}

void ReverseList() {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }

    struct Node* prev = NULL;
    struct Node* current = head;
    struct Node* next;

    do {
        next = current->next;
        current->next = prev;
        prev = current;
        current = next;
    } while (current != head);

    head->next = prev; // Update the head node's next pointer to the last node
    head = prev; // Update the global head to the last node
}

void Display() {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }

    struct Node* temp = head;

    do {
        printf("%d ", temp->data);
        temp = temp->next;
    } while (temp != head);

    printf("\n");
}
