#include <stdio.h>
#include <stdlib.h>

struct Node {
    int id;
    char name[20];
    double salary;
    struct Node* ptr;
};

typedef struct Node node;

node* first = NULL;

node* createnode();

void AddAtEnd();
void Display();

int main() {
    int numStructInputs;
    printf("Enter the number of structure inputs you want to add: ");
    scanf("%d", &numStructInputs);

    for (int i = 0; i < numStructInputs; i++) {
        AddAtEnd();
    }

    Display();

    return 0;
}

void AddAtEnd() {
    node* new;
    new = createnode();

    if (first == NULL) {
        first = new;
    } else {
        node* temp = first;
        while (temp->ptr != NULL) {
            temp = temp->ptr;
        }
        temp->ptr = new;
    }
}

void Display() {
    node* temp = first;
    while (temp != NULL) {
        printf("ID:%d Name:%s Salary:%.2lf\n", temp->id, temp->name, temp->salary);
        temp = temp->ptr;
    }
}

node* createnode() {
    node* new;
    new = malloc(sizeof(node));
    if (new != NULL) {
        printf("Enter the id, name & salary of employee: ");
        scanf("%d,%[^,],%lf", &new->id, new->name, &new->salary);
        new->ptr = NULL;
    }

    return new;
}
