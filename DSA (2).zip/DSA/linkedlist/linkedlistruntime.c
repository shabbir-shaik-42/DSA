#include <stdio.h>
#include <stdlib.h>

struct Node {
    int id;
    struct Node* next;
};

typedef struct Node node;

node* first = NULL;

node* createnode();
void AddAtPos(int position);
void DeleteAtPos(int position);
void DeleteByValue(int idToDelete);
void Display();

int main() {
    int numStructInputs;
    printf("Enter the number of structure inputs you want to add: ");
    scanf("%d", &numStructInputs);

    // First input is inserted at the beginning without specifying a position
   // AddAtPos(1);
   // numStructInputs--;

    for (int i = 0; i < numStructInputs; i++) {
        int position;
        printf("Enter the position to insert structure input: ");
        scanf("%d", &position);
        AddAtPos(position);
    }

    Display();

    int numDeletions;
    printf("Enter the number of structure inputs you want to delete: ");
    scanf("%d", &numDeletions);

    for (int i = 0; i < numDeletions; i++) {
        int choice;
        printf("Delete by (1) Position or (2) Value? ");
        scanf("%d", &choice);

        if (choice == 1) {
            int position;
            printf("Enter the position to delete structure input: ");
            scanf("%d", &position);
            DeleteAtPos(position);
        } else if (choice == 2) {
            int idToDelete;
            printf("Enter the ID of the employee to delete: ");
            scanf("%d", &idToDelete);
            DeleteByValue(idToDelete);
        }

        Display();
    }

    return 0;
}

void AddAtPos(int position) {
    if (position <= 0) {
        printf("Invalid position. Position should be greater than 0.\n");
        return;
    }

    node* new;
    new = createnode();

    if (position == 1 || first == NULL) {
        new->next = first;
        first = new;
        return;
    }

    node* temp = first;
    int currentPos = 1;
    while (temp != NULL && currentPos < position - 1) {
        temp = temp->next;
        currentPos++;
    }

    if (temp == NULL) {
        printf("Position is beyond the length of the linked list. Inserting at the end.\n");
        temp = first;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = new;
    } else {
        new->next = temp->next;
        temp->next = new;
    }
}

void DeleteAtPos(int position) {
    if (position <= 0) {
        printf("Invalid position. Position should be greater than 0.\n");
        return;
    }

    if (position == 1) {
        node* temp = first;
        first = temp->next;
        free(temp);
        return;
    }

    node* temp = first;
    int currentPos = 1;
    while (temp != NULL && currentPos < position - 1) {
        temp = temp->next;
        currentPos++;
    }

    if (temp == NULL || temp->next == NULL) {
        printf("Position is beyond the length of the linked list.\n");
        return;
    }

    node* toDelete = temp->next;
    temp->next = toDelete->next;
    free(toDelete);
}

void DeleteByValue(int idToDelete) {
    if (first == NULL) {
        printf("List is empty. Cannot delete.\n");
        return;
    }

    node* temp = first;
    node* prev = NULL;

    if (temp != NULL && temp->id == idToDelete) {
        first = temp->next;
        free(temp);
        printf("Deleted element with ID %d\n", idToDelete);
        return;
    }

    while (temp != NULL) {
        if (temp->id == idToDelete) {
            prev->next = temp->next;
            free(temp);
            printf("Deleted element with ID %d\n", idToDelete);
            return;
        }
        prev = temp;
        temp = temp->next;
    }

    printf("Element with ID %d not found.\n");
}

void Display() {
    node* temp = first;
    while (temp != NULL) {
        printf("ID:%d\n", temp->id);
        temp = temp->next;
    }
}

node* createnode() {
    node* new;
    new = malloc(sizeof(node));
    if (new != NULL) {
        printf("Enter the id of the employee: ");
        scanf("%d", &new->id);
        new->next = NULL;
    }

    return new;
}

