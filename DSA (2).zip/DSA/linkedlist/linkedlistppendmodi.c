

/*********************************************************************
Date----> 14/10/2023
Name----> B. APUROOP KUMAR

Aim-----> all operations in linked list using pointer to pointer
**********************************************************************************/

#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* next;
};

void AddAtBeg(struct Node** pHead, int data);
void AddAtEnd(struct Node** pHead, int data);
void AddAtPos(struct Node** pHead, int data, int n);
void Delete(struct Node** pHead, int data);
void Display(struct Node* head);
struct Node* CreateNode(int data);

int main() {
    struct Node* head = NULL; // Initialize a local head pointer

    // Insert 10 at the beginning (list is empty)
    AddAtBeg(&head, 10);

    // Insert 11 at the start
    AddAtBeg(&head, 11);

    // Insert 12 at position 1
    AddAtPos(&head, 12, 1);

    // Insert 13 at position 2
    AddAtPos(&head, 13, 2);

    // Display after these operations
    Display(head);

    // Delete 13
    Delete(&head, 13);

    // Insert 14 at the start
    AddAtBeg(&head, 14);

    // Insert 15 at position 1
    AddAtPos(&head, 15, 1);

    // Display after these operations
    Display(head);

    // Delete 14
    Delete(&head, 14);

    // Display after deletion
    Display(head);

    // Insert 16 at the end (list is not empty)
    AddAtEnd(&head, 16);

    // Try to delete 17 (element not found)
    Delete(&head, 17);

    // Try to insert 18 at position 5 (invalid position)
    AddAtPos(&head, 18, 5);

    // Display after these operations
    Display(head);

    return 0;
}

void AddAtBeg(struct Node** pHead, int data) {
    struct Node* temp1 = CreateNode(data);
    temp1->next = *pHead;
    *pHead = temp1;
}

void AddAtEnd(struct Node** pHead, int data) {
    struct Node* newNode = CreateNode(data);

    if (*pHead == NULL) {
        *pHead = newNode;
    } else {
        struct Node* temp1 = *pHead;
        while (temp1->next != NULL) {
            temp1 = temp1->next;
        }
        temp1->next = newNode;
    }
}

void AddAtPos(struct Node** pHead, int data, int n) {
    if (n < 1) {
        printf("Invalid position. Position should be 1 or greater.\n");
        return;
    }

    struct Node* newNode = CreateNode(data);

    if (n == 1) {
        newNode->next = *pHead;
        *pHead = newNode;
        return;
    }

    struct Node* temp = *pHead;
    int currentPos = 1;

    while (currentPos < n - 1 && temp != NULL) {
        temp = temp->next;
        currentPos++;
    }

    if (temp == NULL) {
        printf("Invalid position. Position exceeds the length of the list.\n");
        return;
    }

    newNode->next = temp->next;
    temp->next = newNode;
}

void Delete(struct Node** pHead, int data) {
    if (*pHead == NULL) {
        printf("List is empty\n");
        return;
    }

    struct Node* temp = *pHead;
    struct Node* prev = NULL;

    while (temp != NULL && temp->data != data) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == NULL) {
        printf("Element not found in the list\n");
        return;
    }

    if (prev == NULL) {
        *pHead = temp->next;
      } 
    
        prev->next = temp->next;
    

    free(temp);
}

void Display(struct Node* head) {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }

    printf("List is: ");
    struct Node* temp = head;
    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("\n");
}

struct Node* CreateNode(int data) {
    struct Node* newNode = malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}
