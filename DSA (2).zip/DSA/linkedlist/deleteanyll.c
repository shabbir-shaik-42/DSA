


/*********************************************************************
Date----> 12/10/2023
Name----> B. APUROOP KUMAR

Aim-----> Delete elements in the linked list at any position
**********************************************************************************/


#include <stdio.h>
#include <stdlib.h>

struct Node {
    int id;
    char name[20];
    double salary;
    struct Node* ptr;
};

typedef struct Node node;

node* first = NULL;

node* createnode();

void AddAtPos(int position);
void DeleteAtPos(int position);
void Display();

int main() {
    int numStructInputs;
    printf("Enter the number of structure inputs you want to add: ");
    scanf("%d", &numStructInputs);

    // First input is inserted at the beginning without specifying a position
    AddAtPos(1);
    numStructInputs--;

    for (int i = 0; i < numStructInputs; i++) {
        int position;
        printf("Enter the position to insert structure input: ");
        scanf("%d", &position);
        AddAtPos(position);
    }

    Display();

    int numDeletions;
    printf("Enter the number of structure inputs you want to delete: ");
    scanf("%d", &numDeletions);

    for (int i = 0; i < numDeletions; i++) {
        int position;
        printf("Enter the position to delete structure input: ");
        scanf("%d", &position);
        DeleteAtPos(position);
        Display();
    }

    return 0;
}

void AddAtPos(int position) {
    if (position <= 0) {
        printf("Invalid position. Position should be greater than 0.\n");
        return;
    }

    node* new;
    new = createnode();

    if (position == 1 || first == NULL) {
        new->ptr = first;
        first = new;
        return;
    }

    node* temp = first;
    int currentPos = 1;
    while (temp != NULL && currentPos < position - 1) {
        temp = temp->ptr;
        currentPos++;
    }

    if (temp == NULL) {
        printf("Position is beyond the length of the linked list. Inserting at the end.\n");
        temp = first;
        while (temp->ptr != NULL) {
            temp = temp->ptr;
        }
        temp->ptr = new;
    } else {
        new->ptr = temp->ptr;
        temp->ptr = new;
    }
}

void DeleteAtPos(int position) {
    if (position <= 0) {
        printf("Invalid position. Position should be greater than 0.\n");
        return;
    }

    if (position == 1) {
        node* temp = first;
        first = temp->ptr;
        free(temp);
        return;
    }

    node* temp = first;
    int currentPos = 1;
    while (temp != NULL && currentPos < position - 1) {
        temp = temp->ptr;
        currentPos++;
    }

    if (temp == NULL || temp->ptr == NULL) {
        printf("Position is beyond the length of the linked list.\n");
        return;
    }

    node* toDelete = temp->ptr;
    temp->ptr = toDelete->ptr;
    free(toDelete);
}

void Display() {
    node* temp = first;
    while (temp != NULL) {
        printf("ID:%d Name:%s Salary:%.2lf\n", temp->id, temp->name, temp->salary);
        temp = temp->ptr;
    }
}

node* createnode() {
    node* new;
    new = malloc(sizeof(node));
    if (new != NULL) {
        printf("Enter the id, name & salary of employee: ");
        scanf("%d,%[^,],%lf", &new->id, new->name, &new->salary);
        new->ptr = NULL;
    }

    return new;
}

