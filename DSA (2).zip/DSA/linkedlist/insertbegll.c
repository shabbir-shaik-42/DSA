
/*********************************************************************
Date----> 12/10/2023
Name----> B. APUROOP KUMAR

Aim-----> insertion of  elements in the linked list at beginning
**********************************************************************************/



















#include<stdio.h>
#include<stdlib.h>

struct Node
{
    int id;
    char name[20];
    double salary;
    struct Node *ptr;
};

typedef struct Node node;

node *first = NULL;

node* createnode();

void AddAtBeg();
void Display();

int main()
{
    AddAtBeg();
    AddAtBeg();
    AddAtBeg();
    Display();
    
    return 0;
}

void AddAtBeg()
{
    node *new;                  //initialise a pointer to structure-"node" 
    new = createnode();         //the pointer that points to function createnode 
    if(first == NULL)
        first = new;
    else
    {
        new->ptr = first;
        first = new;
    }
}

void Display()
{
    node *temp = first;
    while(temp != NULL)
    {
        printf("ID:%d Name:%s Salary:%.2lf\n", temp->id, temp->name, temp->salary);
        temp = temp->ptr;
    }
}

node* createnode()
{
    node *new;                  //initialise a pointer to structure-"node" 
    new = malloc(sizeof(node)); //DMA of memory to the structure-"node"
    if(new != NULL)
    {
        printf("Enter the id, name & salary of employee:");
        scanf("%d,%[^,],%lf", &new->id, new->name, &new->salary);
        new->ptr = NULL;
    }
    
    return new;
}
