#include<stdio.h>
#include<stdlib.h>
#define MAX 4
void push(int);
int pop();
void print();
int isFull();
int isEmpty();

int stack_arr[MAX];
int top=-1;

int main(){
    int data;
    for(int i=1;i<=4;i++)
    {
        push(i);
    }
    printf("Elements in the stack:\t");
    print();
	while((data=pop())!=-1)
	{
	    printf("Popped: %d\n",data);
	}
	print();
}
//push operation
void push(int data)
{
    if(isFull()){
	    printf("Stack Overflow");
		return;
	}
	top=top+1;
	stack_arr[top] = data;
}

// pop operation
int pop()
{
    int value;
    // checking stack is empty or not
    if(isEmpty())
    {
        printf("Stack Underflow");
        exit(1); //abnormal termination of the program
    }
    value=stack_arr[top];
    top=top-1;
    return value;
}

void print()
{
    int i;
    if(top==-1)
    {
        printf("Stack Underflow");
        return ;
    }
    for(i=top;i>=0;i--)
    {
        printf("%d ",stack_arr[i]);
    }
    printf("\n");
}

int isFull()
{
    if(top==MAX-1)
        return 1;
    else
        return 0;
}


int isEmpty()
{
    if(top==-1)
        return 1;
    else
        return 0;
}

