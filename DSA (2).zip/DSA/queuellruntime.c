
/**********************************************
Nmae: B.Apuroop Kumar
Date: 16/10/2023

*****************************************/




#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* next;
};

struct Queue {
    struct Node* front;
    struct Node* rear;
    int size; // Track the size of the queue
    int maxSize; // Store the maximum size of the queue
};

struct Queue* createQueue(int maxSize);
void enqueue(struct Queue* q, int data);
int dequeue(struct Queue* q);
int isEmpty(struct Queue* q);
int isFull(struct Queue* q);
void printQueue(struct Queue* q);

int main() {
    int maxSize;
    printf("Enter the maximum size of the queue: ");
    scanf("%d", &maxSize);
    struct Queue* q = createQueue(maxSize);

    int choice;
    int data;

    while (1) {
        printf("\nQueue Operations:\n");
        printf("1. Enqueue\n");
        printf("2. Dequeue\n");
        printf("3. Print Queue\n");
        printf("4. Quit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter the number of elements you want to enqueue: ");
                int numElements;
                scanf("%d", &numElements);

                if (q->size + numElements > q->maxSize) {
                    printf("Queue is full. Cannot enqueue more elements.\n");
                } else {
                    for (int i = 0; i < numElements; i++) {
                        printf("Enter element %d: ", i + 1);
                        scanf("%d", &data);
                        enqueue(q, data);
                    }
                }
                break;
            case 2:
                if (!isEmpty(q)) {
                    int dequeued = dequeue(q);
                    printf("Dequeued: %d\n", dequeued);
                } else {
                    printf("Queue is empty, cannot dequeue.\n");
                }
                break;
            case 3:
                printf("Queue elements:\n");
                printQueue(q);
                break;
            case 4:
                free(q);
                exit(0);
                break;
            default:
                printf("Invalid choice. Please enter a valid option.\n");
        }
    }

    return 0;
}

struct Queue* createQueue(int maxSize) {
    struct Queue* q = (struct Queue*)malloc(sizeof(struct Queue));
    q->front = q->rear = NULL;
    q->size = 0;
    q->maxSize = maxSize;
    return q;
}

void enqueue(struct Queue* q, int data) {
    if (isFull(q)) {
        printf("Queue is full. Cannot enqueue more elements.\n");
        return;
    }

    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->next = NULL;

    if (q->rear == NULL) {
        q->front = q->rear = newNode;
    } else {
        q->rear->next = newNode;
        q->rear = newNode;
    }
    q->size++;
}

int dequeue(struct Queue* q) {
    if (isEmpty(q)) {
        return -1;
    }

    struct Node* temp = q->front;
    q->front = temp->next;

    if (q->front == NULL) {
        q->rear = NULL;
    }

    int data = temp->data;
    free(temp);
    q->size--;
    return data;
}

int isEmpty(struct Queue* q) {
    return q->front == NULL;
}

int isFull(struct Queue* q) {
    return q->size >= q->maxSize;
}

void printQueue(struct Queue* q) {
    if (isEmpty(q)) {
        printf("Queue is empty.\n");
        return;
    }

    printf("Front --> ");
    struct Node* temp = q->front;
    while (temp != NULL) {
        printf("%d", temp->data);
        if (temp->next != NULL) {
            printf(" --> ");
        }
        temp = temp->next;
    }
    printf(" <-- Rear\n");
}
